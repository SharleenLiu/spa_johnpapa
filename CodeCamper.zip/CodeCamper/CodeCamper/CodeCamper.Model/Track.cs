﻿namespace CodeCamper.Model
{
    public class Track
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
